package com.group.sharegram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharegramApplicationTests {

	@Test
	void 제이슨테스트() {
		
	}

}

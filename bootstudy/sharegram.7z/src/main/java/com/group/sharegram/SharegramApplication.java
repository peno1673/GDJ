package com.group.sharegram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SharegramApplication {

	public static void main(String[] args) {
		SpringApplication.run(SharegramApplication.class, args);
	}

}
